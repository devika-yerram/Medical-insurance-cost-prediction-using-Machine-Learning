from django.shortcuts import render
import pickle
import numpy as np

model = pickle.load(open('model.pkl','rb'))

def home(request):
    if request.method == "POST":
        age = int(request.POST.get('age', 0))
        gender = int(request.POST.get('gender', 0))
        bmi = int(request.POST.get('bmi', 0))
        smoker = int(request.POST.get('smoker', 0))
        children = int(request.POST.get('children', 0))
        region = int(request.POST.get('region', 0))

        input_df = (age, gender, bmi, smoker, children, region)
        np_df = np.asarray(input_df)
        input_df_reshaped = np_df.reshape(1,-1)
        prediction = model.predict(input_df_reshaped)
        prediction = round(prediction[0], 2)

        return render(request, 'index.html', {"flag": True, "prediction": prediction})


    return render(request, 'index.html', {})